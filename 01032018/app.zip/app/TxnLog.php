<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TxnLog extends Model
{
    //
}
