@extends('layouts.app')

@section('content')

<h1>Confirm Add</h1>

@endsection