@extends('layouts.cusapp')

@section('content')
<div class="container">
@include('inc.messages')

	<div class="row">
	    <section id="breadcrumb">
	        <div class="container">
	            <ol class="breadcrumb">
	            <li class="active"><h2>Dashboard</h2></li>
	            </ol>
	        </div>
	    </section>
	</div>
    <!-- Website Overview -->
    

  

</div>

@endsection
