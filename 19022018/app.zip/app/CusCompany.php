<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CusCompany extends Model
{
    //
}
